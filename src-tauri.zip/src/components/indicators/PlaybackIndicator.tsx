export function PlaybackIndicator() {
  return (
    <div className="playback-indicator">
      ? Playing
    </div>
  );
}
